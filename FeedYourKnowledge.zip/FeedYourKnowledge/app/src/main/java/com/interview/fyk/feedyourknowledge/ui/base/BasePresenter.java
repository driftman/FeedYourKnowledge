package com.interview.fyk.feedyourknowledge.ui.base;

/**
 * A basic class implementing the presenter interface.
 */

public class BasePresenter<V extends MvpView> {

}
