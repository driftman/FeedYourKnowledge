package com.interview.fyk.feedyourknowledge;

import android.app.Application;

/**
 * Created by abk on 26/01/2018.
 */

public class FeedYourKnowledgeApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }

}
