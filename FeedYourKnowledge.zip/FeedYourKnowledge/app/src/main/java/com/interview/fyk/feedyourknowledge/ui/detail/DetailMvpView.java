package com.interview.fyk.feedyourknowledge.ui.detail;

import com.interview.fyk.feedyourknowledge.ui.base.MvpView;

/**
 * Created by abk on 26/01/2018.
 */

public interface DetailMvpView extends MvpView {


}
